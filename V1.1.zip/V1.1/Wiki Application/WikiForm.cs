﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using System.Web;
using System.Diagnostics;

namespace Wiki_Application
{
    public partial class WikiForm : Form
    {
        // Trace
        static Stream TraceData = File.Create("TraceData.txt");
        TextWriterTraceListener imAlreadyTracer = new TextWriterTraceListener(TraceData);

        // 6.2 Create a global List<T> of type Information called Wiki
        List<Information> Wiki = new List<Information>();

        // 6.4 Create and initialise a global string array with the six categories as indicated in the Data Structure Matrix.
        // I read contains the 6 as a minimum but not limited to, hence adding the emtry entry to enable viewing of the whole list at once.
        //string[] cbFiller = new string[] { "Array", "List", "Tree", "Graphs", "Abstract", "Hash", "" };
        string[] cbFiller = System.IO.File.ReadAllLines(Path.Combine(System.AppDomain.CurrentDomain.BaseDirectory, "cbFiller.txt"));
        

        public WikiForm()
        {
            InitializeComponent();
            //  Create a custom method to populate the ComboBox when the Form Load method is called.
            PopulateComboBox();
        }

        // 6.3 Create a button method to ADD a new item to the list
        private void buttonAdd_Click(object sender, EventArgs e)
        {
            try
            {
                if (textBoxName.Text != null && comboBoxCategory.SelectedItem != null)
                {
                    if (!ValidName(textBoxName.Text))
                    {
                        string structureTemp = RadioStringReturn();
                        Wiki.Add(new Information(textBoxName.Text, comboBoxCategory.Text, structureTemp, textBoxDefinition.Text));
                        DisplayList();
                    }
                }
            }
            catch (Exception ex)
            { }
        }


        // 6.7 Create a button method that will delete the currently selected record in the ListView.
        // Ensure the user has the option to backout of this action by using a dialog box. Display an updated version of the sorted list at the end of this process.
        private void buttonDelete_Click(object sender, EventArgs e)
        {
            MessageBoxButtons buttons = MessageBoxButtons.YesNo;

            DialogResult result = MessageBox.Show("Do you want to delete?", "Delete?", buttons);

            Trace.Listeners.Add(imAlreadyTracer);
            Trace.AutoFlush = true;
            Trace.Indent();

            try
            {
                if (result == DialogResult.Yes)
                {
                    if (listViewInfo.SelectedIndices[0] >= 0 && listViewInfo.SelectedIndices[0] <= Wiki.Count)
                    {
                        string temp = textBoxName.Text;
                        Wiki.RemoveAt(TrueIndex());
                        DisplayList();

                        ClearInfo();

                        comboBoxCategory.SelectedIndex = 6;

                        Trace.WriteLine("buttonDelete_Click (BDC): object " + temp + " deleted and selected combo index returned to view all");
                    }
                }
                else
                    Trace.WriteLine("buttonDelete_Click (BDC): user declined dialog box");
            }
            catch (Exception ex)
            { 
                Trace.WriteLine("buttonDelete_Click (BDC): cannot delete without selecting a valid item");
            }
            Trace.Unindent();
        }


        // Editable within categorys
        // 6.8 Create a button method that will save the edited record of the currently selected item in the ListView.
        // All the changes in the input controls will be written back to the list. Display an updated version of the sorted list at the end of this process.
        private void buttonEdit_Click(object sender, EventArgs e)
        {
            Trace.Listeners.Add(imAlreadyTracer);
            Trace.AutoFlush = true;
            Trace.Indent();
            bool tIndex = true;

            string newName = textBoxName.Text;
            if (listViewInfo.SelectedItems.Count > 0)
            {
                int curItem = TrueIndex();

                bool valid = ValidName(Wiki[curItem].getName());
                //bool valid = Wiki.Exists(x => x.getName() == Wiki[curItem].getName());
                if (valid)
                {
                    //if (tIndex)
                    //Trace.WriteLine("buttonEdit_Click (BEC): name " + Wiki[curItem].getName() + " is valid: " + valid);

                    Wiki[curItem].setName(textBoxName.Text);
                    Wiki[curItem].setCategory(comboBoxCategory.Text);
                    Wiki[curItem].setStructure(RadioStringReturn());
                    Wiki[curItem].setDefinition(textBoxDefinition.Text);

                    if (tIndex)
                        Trace.WriteLine("buttonEdit_Click (BEC): name: " + textBoxName.Text + "\n\t\t\t\t category: " + comboBoxCategory.Text + "\n\t\t\t\t structure: " + RadioStringReturn() + "\n\t\t\t\t definition: " + textBoxDefinition.Text + "\n\n");

                    tIndex = false;
                }
                else
                    Trace.Assert(valid, "buttonEdit_Click (BEC): name was not valid\n\n");
            }
            else
                Trace.WriteLine("buttonEdit_Click (BEC): no item selected");

            DisplayList();

            Trace.Unindent();
        }

        // 6.10 Create a button method that will use the builtin binary search to find a Data Structure name.
        // If the record is found the associated details will populate the appropriate input controls and highlight the name in the ListView.
        // At the end of the search process the search input TextBox must be cleared.
        private void buttonSearch_Click(object sender, EventArgs e)
        {
            // if (!string.IsNullOrEmpty(textBoxSearch.Text))
            // {
            //     string searchTerm = textBoxSearch.Text;
            //     int index = 0;

            //     foreach (var i in Wiki)
            //     {
            //         if (i.getName() == searchTerm)
            //         {
            //             comboBoxCategory.Text = i.getCategory();
            //             int num = LargeToSmallIndex(searchTerm, i.getCategory());
            //             listViewInfo.Items[num].Selected = true;
            //         }
            //         index++;
            //     }
            // }
            try
            {
                int index = 0;
                Information temp = new Information(textBoxSearch.Text, "", "", "");
                index = Wiki.BinarySearch(temp);
                int num = LargeToSmallIndex(textBoxSearch.Text, Wiki[index].getCategory());

                int tempIndex = 0;
                string[] cats = new string[] { "Array", "List", "Tree", "Graphs", "Abstract", "Hash", "" };
                while (Wiki[index].getCategory() != cats[tempIndex])
                    tempIndex++;
                //ClickList(num, textBoxSearch.Text);
                //int c = LargeToSmallIndex(textBoxSearch.Text, comboBoxCategory.Text);
                //comboBoxCategory.SelectedItem = Wiki[index].getCategory();

                //listViewInfo.Items[num].Selected = true;

                comboBoxCategory.SelectedIndex = tempIndex;

                string structureType = Wiki[index].getStructure();
                if (structureType == "Linear")
                {
                    RadioIntSet(1);
                }
                else if (structureType == "Non-Linear")
                {
                    RadioIntSet(0);
                }
                else
                {
                    radioButtonLinear.Checked = false;
                    radioButtonNonLinear.Checked = false;
                }

                textBoxDefinition.Text = Wiki[index].getDefinition();

                textBoxName.Text = textBoxSearch.Text;

                listViewInfo.Focus();
                listViewInfo.Items[index].Selected = true;

                textBoxSearch.Text = "";
            }
            catch (Exception ex)
            { 
                
            }
        }

        // 6.14 Create two buttons for the manual open and save option; this must use a dialog box to select a file or rename a saved file. All Wiki data is stored/retrieved using a binary file format.
        private void buttonOpen_Click(object sender, EventArgs e)
        {
            Wiki.Clear();

            var filePath = string.Empty;

            using (OpenFileDialog openFileDialog = new OpenFileDialog())
            {
                openFileDialog.InitialDirectory = Path.Combine(System.AppDomain.CurrentDomain.BaseDirectory, "data");
                openFileDialog.Filter = "bin files (*.bin)|*.bin";
                openFileDialog.FilterIndex = 2;
                openFileDialog.RestoreDirectory = true;
                int index = 0;

                if (openFileDialog.ShowDialog() == DialogResult.OK)
                {
                    try
                    {
                        using (Stream stream = File.Open(openFileDialog.FileName, FileMode.Open))
                        {
                            BinaryFormatter bin = new BinaryFormatter();
                            while (stream.Position < stream.Length)
                            {
                                Wiki.Add(new Information());
                                Wiki[index].setName((string)bin.Deserialize(stream));
                                Wiki[index].setCategory((string)bin.Deserialize(stream));
                                Wiki[index].setStructure((string)bin.Deserialize(stream));
                                Wiki[index].setDefinition((string)bin.Deserialize(stream));
                                index++;
                            }
                        }
                        StatusStrip.Text = "File successfully opened!";
                    }
                    catch (IOException ex)
                    {
                        MessageBox.Show(ex.ToString());
                    }
                }
            }
            DisplayList();
        }

        // 6.14 Create two buttons for the manual open and save option; this must use a dialog box to select a file or rename a saved file.All Wiki data is stored/retrieved using a binary file format.
        private void buttonSave_Click(object sender, EventArgs e)
        {
            SaveInformation();
        }

        // 6.9 Create a single custom method that will sort and then display the Name and Category from the wiki information in the list.
        private void DisplayList() 
        { 
            listViewInfo.Items.Clear();

            // SortArray();
            // Single method so SortArray() method removed

            int listLen = Wiki.Count();
            for (int i = 0; i < listLen - 1; i++)
            {
                for (int j = i + 1; j < listLen; j++)
                {
                    if (String.Compare(Wiki[i].getName(), Wiki[j].getName()) > 0)
                    {
                        Swap(i, j);
                    }
                }
            }

            if (comboBoxCategory.Text != "")
            {
                foreach (var Information in Wiki)
                {
                    ListViewItem item = new ListViewItem(new[] { Information.getName(), Information.getCategory() });
                    if (Information.getCategory() == comboBoxCategory.Text)
                        listViewInfo.Items.Add(item);
                }
            }
            else
            {
                foreach (var Information in Wiki)
                {
                    ListViewItem item = new ListViewItem(new[] { Information.getName(), Information.getCategory() });
                    listViewInfo.Items.Add(item);
                }
            }
        }
        

        // requirements specified a single method so I guess this isn't getting used
        private void SortArray()
        {
        //    int listLen = Wiki.Count();
        //    for (int i = 0; i < listLen - 1; i++)
        //    {
        //        for (int j = i + 1; j < listLen; j++)
        //        {
        //            if (String.Compare(Wiki[i].getName(), Wiki[j].getName()) > 0)
        //            {
        //                Swap(i, j);
        //            }
        //        }
        //    }
        }

        private void Swap(int i, int j)
        {
            Information temp = new Information("t", "e", "s", "t");

            temp = Wiki[i];
            Wiki[i] = Wiki[j];
            Wiki[j] = temp;
        }


        // 6.5 Create a custom ValidName method which will take a parameter string value from the Textbox Name and returns a Boolean after checking for duplicates.
        // Use the built in List<T> method “Exists” to answer this requirement.
        private bool ValidName(string name)
        {
            //int valid = 1;
            //foreach (var i in Wiki)
            //{
            //    if (textBoxName.Text != null || textBoxName.Text != "")
            //    {
            //        if (i.getName() == textBoxName.Text)
            //        {
            //            valid = 0;
            //        }
            //    }
            //}
            Trace.Listeners.Add(imAlreadyTracer);
            Trace.AutoFlush = true;
            Trace.Indent();

            bool valid = Wiki.Exists(x => x.getName() == name);

            if (!valid)
            Trace.WriteLine("ValidName: name " + name + " does not exist\n\n");

            if (valid)
                Trace.WriteLine("ValidName: name " + name + " exists\n\n");
            
            Trace.Unindent();

            return valid;
        }

        private void listViewInfo_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void comboBoxCategory_SelectedIndexChanged(object sender, EventArgs e)
        {
            DisplayList();
        }

        private int TrueIndex()
        {
            try
            {
                string name = listViewInfo.SelectedItems[0].Text;
                int curIndex = 0, nameIndex = 0;
                foreach (var i in Wiki)
                {
                    if (i.getName() == name)
                        curIndex = nameIndex;
                    nameIndex++;
                }
                return curIndex;
            }
            catch (Exception ex)
            { 
            }
            return 0;
        }

        private int LargeToSmallIndex(string searchTerm, string category) 
        {
            int index = 0, num = 0;
            foreach (var i in Wiki)
            {
                if (searchTerm == i.getName())
                    num = index;

                if (i.getCategory() == category)
                    index++;
            }
            return num;
        }

        // 6.11 Create a ListView event so a user can select a Data Structure Name from the list of Names
        // and the associated information will be displayed in the related text boxes combo box and radio button.
        private void listViewInfo_Click(object sender, EventArgs e)
        {
            try
            {
                int num = 0;
                int curIndex = 0;

                string selName = listViewInfo.SelectedItems[0].Text;
                comboBoxCategory.SelectedIndex = 6;
                foreach (var i in Wiki)
                {
                    if (i.getName().Equals(selName))
                        curIndex = num;
                    num++;
                }

                int index = 0;

                textBoxName.Text = Wiki[curIndex].getName();

                string cCategory = Wiki[curIndex].getCategory();
                List<string> categoryIndexList = new List<string> { "Array", "List", "Tree", "Graphs", "Abstract", "Hash", "" };
                foreach (string i in categoryIndexList)
                {
                    if (i == cCategory)
                        break;
                    index++;
                }

                comboBoxCategory.SelectedIndex = index;

                string structureType = Wiki[curIndex].getStructure();
                if (structureType == "Linear")
                {
                    radioButtonLinear.Checked = true;
                    radioButtonNonLinear.Checked = false;
                }
                else if (structureType == "Non-Linear")
                {
                    radioButtonLinear.Checked = false;
                    radioButtonNonLinear.Checked = true;
                }
                else
                {
                    radioButtonLinear.Checked = false;
                    radioButtonNonLinear.Checked = false;
                }

                textBoxDefinition.Text = Wiki[curIndex].getDefinition();

                int c = LargeToSmallIndex(selName, comboBoxCategory.Text);
                listViewInfo.Items[c].Selected = true;

                // _ = listViewInfo.Items[curIndex].Selected == true;
            }
            catch (Exception ex)
            {

            }
        }

        // 6.6 Create two methods to highlight and return the values from the Radio button GroupBox.
        // The first method must return a string value from the selected radio button (Linear or Non-Linear). 
        private string RadioStringReturn() 
        {
            string radioType = "";

            if (radioButtonLinear.Checked == true)
                radioType = "Linear";

            if (radioButtonNonLinear.Checked == true)
                radioType = "Non-Linear";

            return radioType;
        }

        // The second method must send an integer index which will highlight an appropriate radio button.
        private void RadioIntSet(int radioType)
        {
            if (radioType == 0)
            {
                radioButtonNonLinear.Checked = true;
                radioButtonLinear.Checked = false;
            }

            if (radioType == 1)
            {
                radioButtonNonLinear.Checked = false;
                radioButtonLinear.Checked = true;
            }

        }

        private int CheckIfExists()
        {
            //if (TrueIndex() <= Wiki.Count && TrueIndex() >= 0)
            //    return 1;
            //else
                return 0;
        }

        // 6.12 Create a custom method that will clear and reset the TextBboxes, ComboBox and Radio button
        private void ClearInfo()
        {
            textBoxName.Text = "";
            comboBoxCategory.SelectedIndex = 6;
            radioButtonLinear.Checked = false;
            radioButtonNonLinear.Checked = false;
            textBoxDefinition.Text = "";
        }

        // 6.13 Create a double click event on the Name TextBox to clear the TextBboxes, ComboBox and Radio button.
        private void textBoxName_DoubleClick(object sender, EventArgs e)
        {
            ClearInfo();
        }

        private void SaveInformation()
        {
            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.Filter = "bin files (*.bin)|*.bin";
            saveFileDialog.Title = "Save Wiki Data";

            if (saveFileDialog.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    using (Stream stream = File.Open(saveFileDialog.FileName, FileMode.Create))
                    {
                        BinaryFormatter bin = new BinaryFormatter();
                        foreach (var Information in Wiki)
                        {
                            bin.Serialize(stream, Information.getName());
                            bin.Serialize(stream, Information.getCategory());
                            bin.Serialize(stream, Information.getStructure());
                            bin.Serialize(stream, Information.getDefinition());
                        }
                    }
                    StatusStripLabel.Text = "Saved successfully!";
                }
                catch (IOException ex)
                {
                    MessageBox.Show(ex.ToString());
                    StatusStripLabel.Text = "Save failed!";
                }
            }
        }


        // 6.15 The Wiki application will save data when the form closes. 
        private void WikiForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            SaveInformation();
        }

        private void PopulateComboBox()
        {
            Array.Resize(ref cbFiller, cbFiller.Length + 1);
            cbFiller[cbFiller.Length - 1] = "";
            comboBoxCategory.Items.AddRange(cbFiller);
        }
    }
}

