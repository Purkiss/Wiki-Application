﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Wiki_Application
{
    // 6.1 Create a separate class file to hold the four data items of the Data Structure
    internal class Information : IComparable<Information>
    {
        private string name, category, structure, definition;

        public Information() { 
        
        }

        public Information(string iName, string iCategory, string iStructure, string iDefinition) {
            name = iName;
            category = iCategory;  
            structure = iStructure;
            definition = iDefinition;
        }

        public string getName()
        {
            return name;
        }
        public void setName(string i) 
        { 
            name = i;
        }


        public string getCategory()
        {
            return category;
        }
        public void setCategory(string i)
        {
            category = i;
        }


        public string getStructure()
        {
            return structure;
        }
        public void setStructure(string i)
        {
            structure = i;
        }


        public string getDefinition()
        {
            return definition;
        }
        public void setDefinition(string i)
        {
            definition = i;
        }

        public int CompareTo(Information x)
        {
            if (x.name == name) return 0;
            if (x.name == null ) return -1;
            if (name == null) return 1;

            return String.Compare(name, x.name);
        }
    }
}
